This script activates a mini-turbo boost when the character runs, similar to Super Mario 3D World.

To activate it in your level, create a file named luna.lua and add the following:

local turbo = require("3dw-turbo")
Play the level and run. That's it!

Author: RicqdWii