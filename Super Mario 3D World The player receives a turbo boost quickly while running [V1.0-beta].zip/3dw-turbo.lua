local turbo = {}

-- Tablas para guardar los datos individuales de cada jugador
local timers = { [1] = 0, [2] = 0 }
local sounds = { [1] = false, [2] = false }
local momentums = { [1] = 0, [2] = 0 }

-- Carga del sprite personalizado
local humoImg = nil
local imagePath = Misc.resolveFile("3dw-turbo/effect-74.png")
if imagePath then
    humoImg = Graphics.loadImage(imagePath)
end

-- CONFIGURACIÓN
local WALK_SPEED = 4.3      
local RUN_SPEED = 6.4       
local TURBO_SPEED = 9.2     
local SPRINT_THRESHOLD = 65 

local charactersAllowed = {
    [CHARACTER_MARIO] = true, [CHARACTER_LUIGI] = true,
    [CHARACTER_PEACH] = true, [CHARACTER_TOAD] = true, [CHARACTER_ROSALINA] = true
}

function turbo.onTick()
    -- Recorremos a todos los jugadores (J1 y J2)
    for i, p in ipairs(Player.get()) do
        
        -- Si el personaje no está permitido, saltamos al siguiente jugador
        if charactersAllowed[p.character] then

            local onGround = (p:mem(0x122, FIELD_WORD) == 0)
            local pressingDir = (p.rawKeys.left or p.rawKeys.right)
            local pressingRun = p.rawKeys.run 
            
            -- 1. Si suelta el mando o el botón de correr
            if not pressingDir or not pressingRun then
                timers[i] = 0
                momentums[i] = 0
                sounds[i] = false
            end

            -- 2. El resbalón al girar (Anti-Slip)
            if onGround and pressingDir then
                if (p.speedX > 2 and p.rawKeys.left) or (p.speedX < -2 and p.rawKeys.right) then
                    p.speedX = p.speedX * 0.88
                    timers[i] = 0
                    momentums[i] = 0
                    sounds[i] = false
                end
            end

            -- 3. Lógica en Suelo
            if onGround then
                if math.abs(p.speedX) > 1 and pressingRun and pressingDir then
                    timers[i] = timers[i] + 1
                else
                    timers[i] = 0
                    sounds[i] = false
                end

                if timers[i] >= SPRINT_THRESHOLD then
                    p.speedX = TURBO_SPEED * math.sign(p.speedX)
                    p:mem(0x114, FIELD_WORD, 2) -- Estado de carrera P-Meter
                    
                    if not sounds[i] then
                        SFX.play(58) 
                        sounds[i] = true
                    end
                    
                    -- Partículas
                    if lunatime.tick() % 4 == 0 then
                        local e = Effect.spawn(74, p.x + (p.width/2) - 8, p.y + p.height - 8)
                        if humoImg then e.img = humoImg end
                    end
                elseif pressingDir then
                    local limit = pressingRun and RUN_SPEED or WALK_SPEED
                    if math.abs(p.speedX) > limit then
                        p.speedX = limit * math.sign(p.speedX)
                    end
                end
                
                momentums[i] = p.speedX
            else
                -- 4. Lógica en el AIRE
                if math.abs(momentums[i]) > RUN_SPEED and pressingDir and pressingRun then
                    p.speedX = momentums[i]
                    p:mem(0x114, FIELD_WORD, 2)
                    
                    if p:mem(0x148, FIELD_WORD) ~= 0 or p:mem(0x14C, FIELD_WORD) ~= 0 then
                        momentums[i] = 0
                        timers[i] = 0
                    end
                else
                    momentums[i] = 0
                end
            end
        end -- fin charactersAllowed
    end -- fin loop for
end

registerEvent(turbo, "onTick")
return turbo